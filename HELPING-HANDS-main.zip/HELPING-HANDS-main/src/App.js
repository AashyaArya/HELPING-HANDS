
import './App.css';
import Navbar from './Components/Navbar';
import AllRoute from './Pages/AllRouter';

function App() {
  return (
    <div className="App">
      <AllRoute/>
    </div>
  );
}

export default App;
